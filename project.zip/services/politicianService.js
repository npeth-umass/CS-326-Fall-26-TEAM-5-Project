import * as politicianRepository from '../repositories/politicianRepository.js';

const PARTIES = ['Democratic', 'Republican', 'Independent', 'Independent Democrat', 'Libertarian'];
const PARTY_ALIASES = {
  d: 'Democratic',
  dem: 'Democratic',
  democrat: 'Democratic',
  r: 'Republican',
  rep: 'Republican',
  gop: 'Republican',
  i: 'Independent',
  ind: 'Independent',
  id: 'Independent Democrat',
  l: 'Libertarian',
  lib: 'Libertarian',
};

const CHAMBERS = ['House of Representatives', 'Senate'];
const CHAMBER_ALIASES = {
  house: 'House of Representatives',
  'house of representatives': 'House of Representatives',
  representative: 'House of Representatives',
  senate: 'Senate',
  senator: 'Senate',
};

const STATES = {
  AL: 'Alabama', AK: 'Alaska', AZ: 'Arizona', AR: 'Arkansas', CA: 'California',
  CO: 'Colorado', CT: 'Connecticut', DE: 'Delaware', FL: 'Florida', GA: 'Georgia',
  HI: 'Hawaii', ID: 'Idaho', IL: 'Illinois', IN: 'Indiana', IA: 'Iowa',
  KS: 'Kansas', KY: 'Kentucky', LA: 'Louisiana', ME: 'Maine', MD: 'Maryland',
  MA: 'Massachusetts', MI: 'Michigan', MN: 'Minnesota', MS: 'Mississippi', MO: 'Missouri',
  MT: 'Montana', NE: 'Nebraska', NV: 'Nevada', NH: 'New Hampshire', NJ: 'New Jersey',
  NM: 'New Mexico', NY: 'New York', NC: 'North Carolina', ND: 'North Dakota', OH: 'Ohio',
  OK: 'Oklahoma', OR: 'Oregon', PA: 'Pennsylvania', RI: 'Rhode Island', SC: 'South Carolina',
  SD: 'South Dakota', TN: 'Tennessee', TX: 'Texas', UT: 'Utah', VT: 'Vermont',
  VA: 'Virginia', WA: 'Washington', WV: 'West Virginia', WI: 'Wisconsin', WY: 'Wyoming',
  DC: 'District of Columbia', PR: 'Puerto Rico', GU: 'Guam', VI: 'Virgin Islands',
  AS: 'American Samoa', MP: 'Northern Mariana Islands',
};
const STATE_NAMES = Object.values(STATES);

const EDITABLE_FIELDS = ['name', 'party', 'state', 'district', 'chamber', 'bioguideId', 'imageUrl'];
const BIOGUIDE_FORMAT = /^[A-Z]\d{6}$/; // e.g. L000174
const NAME_FORMAT = /^[^,]+,\s*[^,].*$/; // "Last, First ..." as Congress.gov writes it

// ---------------------------------------------------------------------------
// Result helpers
// ---------------------------------------------------------------------------

const ok = (value) => ({ ok: true, value });
const fail = (status, message, details) => ({
  ok: false,
  error: details ? { status, message, details } : { status, message },
});

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

const isNonEmptyString = (v) => typeof v === 'string' && v.trim() !== '';
const tidy = (v) => (typeof v === 'string' ? v.trim().replace(/\s+/g, ' ') : v);

/** Lookup key: case-, spacing- and accent-insensitive ("Velázquez, Nydia" == "velazquez,  nydia"). */
const keyOf = (name) =>
  String(name)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase();

const bioguideKeyOf = (id) => `bioguide:${String(id).toLowerCase()}`;

function canonicalParty(value) {
  const v = tidy(value);
  if (typeof v !== 'string') return v;
  return PARTY_ALIASES[v.toLowerCase()] ?? PARTIES.find((p) => p.toLowerCase() === v.toLowerCase()) ?? v;
}

function canonicalChamber(value) {
  const v = tidy(value);
  if (typeof v !== 'string') return v;
  return CHAMBER_ALIASES[v.toLowerCase()] ?? v;
}

function canonicalState(value) {
  const v = tidy(value);
  if (typeof v !== 'string') return v;
  return STATES[v.toUpperCase()] ?? STATE_NAMES.find((s) => s.toLowerCase() === v.toLowerCase()) ?? v;
}

function isHttpUrl(value) {
  try {
    const { protocol } = new URL(value);
    return protocol === 'http:' || protocol === 'https:';
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Mapping: raw Congress.gov member -> our politician shape
// ---------------------------------------------------------------------------

function latestChamber(member) {
  // `terms` is { item: [...] } in the JSON API, but tolerate a bare array as well.
  const terms = Array.isArray(member.terms) ? member.terms : member.terms?.item;
  if (!Array.isArray(terms) || terms.length === 0) return null;
  return terms[terms.length - 1]?.chamber ?? null;
}

/** Copies the Congress.gov values as they are. */
function fromCongressMember(member) {
  return {
    bioguideId: member.bioguideId ?? null,
    name: member.name ?? null,
    party: member.partyName ?? null,
    state: member.state ?? null,
    district: member.district ?? null,
    chamber: latestChamber(member),
    imageUrl: member.depiction?.imageUrl ?? null,
    source: 'congress.gov',
    edited: false,
  };
}

// ---------------------------------------------------------------------------
// Validation: only used to stop badly formatted data being saved by POST / PUT
// ---------------------------------------------------------------------------

/** Returns a list of human-readable problems. An empty list means the record is OK to save. */
function validatePolitician(p) {
  const issues = [];

  if (!isNonEmptyString(p.name)) {
    issues.push('name is required');
  } else {
    if (!NAME_FORMAT.test(p.name)) issues.push('name must be in "Last, First" format (e.g. "Warren, Elizabeth")');
    if (/\d/.test(p.name)) issues.push('name must not contain digits');
  }

  if (!isNonEmptyString(p.party)) issues.push('party is required');
  else if (!PARTIES.includes(p.party)) issues.push(`party must be one of: ${PARTIES.join(', ')}`);

  if (!isNonEmptyString(p.state)) issues.push('state is required');
  else if (!STATE_NAMES.includes(p.state)) issues.push('state must be a full state or territory name (e.g. "Massachusetts")');

  if (!isNonEmptyString(p.chamber)) issues.push('chamber is required');
  else if (!CHAMBERS.includes(p.chamber)) issues.push(`chamber must be one of: ${CHAMBERS.join(', ')}`);

  const hasDistrict = p.district !== null && p.district !== undefined;
  if (hasDistrict && !(Number.isInteger(p.district) && p.district >= 0)) {
    issues.push('district must be a whole number, 0 or greater (0 means at-large)');
  } else if (hasDistrict && p.chamber === 'Senate') {
    issues.push('district must be empty for senators');
  }

  if (p.bioguideId !== null && p.bioguideId !== undefined && !BIOGUIDE_FORMAT.test(p.bioguideId)) {
    issues.push('bioguideId must be one letter followed by six digits (e.g. "W000817")');
  }

  if (p.imageUrl !== null && p.imageUrl !== undefined && !(typeof p.imageUrl === 'string' && isHttpUrl(p.imageUrl))) {
    issues.push('imageUrl must be a valid http(s) URL');
  }

  return issues;
}

/**
 * Cleans up user input (trims, expands "MA" -> "Massachusetts", "D" -> "Democratic", ...).
 * Only fields that were actually sent are returned, so it works for partial updates.
 * Values that can't be understood are passed through untouched and rejected by validatePolitician.
 */
function normalizeInput(body) {
  const value = {};
  const issues = [];

  for (const field of Object.keys(body)) {
    if (!EDITABLE_FIELDS.includes(field)) issues.push(`unknown field "${field}"`);
  }

  if ('name' in body) value.name = tidy(body.name);
  if ('party' in body) value.party = canonicalParty(body.party);
  if ('state' in body) value.state = canonicalState(body.state);
  if ('chamber' in body) value.chamber = canonicalChamber(body.chamber);

  if ('district' in body) {
    const d = body.district;
    if (d === null || d === '') value.district = null;
    else if (typeof d === 'string' && /^\d+$/.test(d.trim())) value.district = Number(d.trim());
    else value.district = d;
  }

  if ('bioguideId' in body) {
    const b = body.bioguideId;
    value.bioguideId = b === null || b === '' ? null : typeof b === 'string' ? b.trim().toUpperCase() : b;
  }

  if ('imageUrl' in body) {
    const u = body.imageUrl;
    value.imageUrl = u === null || u === '' ? null : typeof u === 'string' ? u.trim() : u;
  }

  return { value, issues };
}

// ---------------------------------------------------------------------------
// Loading: Congress.gov data + local corrections
// ---------------------------------------------------------------------------

async function loadAll() {
  const [members, store] = await Promise.all([
    politicianRepository.fetchCongressMembers(),
    politicianRepository.readStore(),
  ]);

  const politicians = new Map();
  const upstreamKeys = new Set();

  for (const member of members) {
    const record = fromCongressMember(member);
    let key = isNonEmptyString(record.name) ? keyOf(record.name) : null;
    // Nameless or duplicate-named entries fall back to their bioguide id so nothing is lost.
    if ((!key || politicians.has(key)) && record.bioguideId) key = bioguideKeyOf(record.bioguideId);
    if (!key || politicians.has(key)) continue;
    politicians.set(key, record);
    upstreamKeys.add(key);
  }

  for (const key of store.deleted) politicians.delete(key);
  for (const [key, record] of Object.entries(store.records)) politicians.set(key, record);

  return { politicians, upstreamKeys };
}

/** Run an operation, turning repository failures into result objects. */
async function guarded(operation) {
  try {
    return await operation();
  } catch (err) {
    if (err instanceof politicianRepository.CongressApiError) return fail(err.status, err.message);
    throw err; // unexpected: let the error handler in server.js deal with it
  }
}

// ---------------------------------------------------------------------------
// Public API (used by the controller)
// ---------------------------------------------------------------------------

/**
 * With no name: every politician, plus the distinct states and chambers they belong to.
 * With a name:  only politicians whose name matches (case-, spacing- and accent-insensitive).
 * Results are returned in the order they come in; no sorting.
 */
export function listPoliticians(searchName) {
  return guarded(async () => {
    const { politicians } = await loadAll();
    const all = [...politicians.values()];

    if (searchName !== undefined) {
      const needle = keyOf(searchName);
      return ok({
        politicians: all.filter((p) => isNonEmptyString(p.name) && keyOf(p.name).includes(needle)),
      });
    }

    const distinct = (field) => [...new Set(all.map((p) => p[field]).filter(isNonEmptyString))];
    return ok({
      politicians: all,
      states: distinct('state'),
      chambers: distinct('chamber'),
    });
  });
}

/** Add a new politician (all of name, party, state and chamber are required). */
export function createPolitician(body) {
  return guarded(async () => {
    const { value, issues } = normalizeInput(body);
    const record = {
      bioguideId: null,
      district: null,
      imageUrl: null,
      ...value,
      source: 'user',
      edited: false,
    };
    issues.push(...validatePolitician(record));
    if (issues.length > 0) return fail(400, 'Politician is not formatted correctly', issues);

    const key = keyOf(record.name);
    const { politicians } = await loadAll();
    if (politicians.has(key)) {
      return fail(409, `"${record.name}" already exists. Use PUT /politicians/:name to change it.`);
    }

    await politicianRepository.commitChanges({ set: { [key]: record } });
    return ok(record);
  });
}

export function updatePolitician(nameParam, body) {
  return guarded(async () => {
    const { politicians, upstreamKeys } = await loadAll();
    const oldKey = keyOf(nameParam);
    const existing = politicians.get(oldKey);
    if (!existing) return fail(404, `No politician named "${nameParam}"`);

    if (Object.keys(body).length === 0) {
      return fail(400, `Nothing to update. Send at least one of: ${EDITABLE_FIELDS.join(', ')}`);
    }

    const { value, issues } = normalizeInput(body);
    const updated = { ...existing, ...value, edited: true };
    issues.push(...validatePolitician(updated));
    if (issues.length > 0) return fail(400, 'Update would leave the politician badly formatted', issues);

    const newKey = keyOf(updated.name);
    if (newKey !== oldKey) {
      if (politicians.has(newKey)) return fail(409, `"${updated.name}" already exists`);
      await politicianRepository.commitChanges({
        remove: [oldKey],
        hide: upstreamKeys.has(oldKey) ? [oldKey] : [], // keep the original Congress.gov entry from reappearing
        set: { [newKey]: updated },
      });
    } else {
      await politicianRepository.commitChanges({ set: { [oldKey]: updated } });
    }

    return ok(updated);
  });
}

/** Delete a politician. Congress.gov entries are hidden locally (we can't delete upstream data). */
export function deletePolitician(nameParam) {
  return guarded(async () => {
    const { politicians, upstreamKeys } = await loadAll();
    const key = keyOf(nameParam);
    const existing = politicians.get(key);
    if (!existing) return fail(404, `No politician named "${nameParam}"`);

    await politicianRepository.commitChanges({
      remove: [key],
      hide: upstreamKeys.has(key) ? [key] : [],
    });
    return ok(existing);
  });
}
