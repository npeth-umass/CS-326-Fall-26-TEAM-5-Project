import { Router } from "express";
import * as controller from "../controllers/politicianController.js";

const router = Router();

router.get("/", controller.list);
router.post("/", controller.add);
router.delete("/:name", controller.remove);

export default router;
