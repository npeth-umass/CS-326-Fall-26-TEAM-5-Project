const rows = document.getElementById("rows");
const empty = document.getElementById("empty");
const msg = document.getElementById("msg");
const filters = document.getElementById("filters");

async function load() {
  const params = new URLSearchParams();
  for (const el of filters.querySelectorAll("input, select")) {
    if (el.value) params.set(el.name, el.value);
  }
  const { members } = await (await fetch("/politicians?" + params)).json();

  rows.replaceChildren();
  empty.hidden = members.length > 0;
  for (const p of members) {
    const tr = rows.insertRow();
    for (const v of [p.name, p.party, p.state, p.district ?? "", p.chamber]) {
      tr.insertCell().textContent = v;
    }
    const btn = document.createElement("button");
    btn.className = "del";
    btn.textContent = "Delete";
    btn.onclick = async () => {
      await fetch("/politicians/" + encodeURIComponent(p.name), { method: "DELETE" });
      load();
    };
    tr.insertCell().append(btn);
  }
}

filters.addEventListener("input", load);

document.getElementById("add").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const res = await fetch("/politicians", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(Object.fromEntries(new FormData(form))),
  });
  msg.textContent = res.ok ? "" : (await res.json()).error;
  if (res.ok) { form.reset(); load(); }
});

load();
