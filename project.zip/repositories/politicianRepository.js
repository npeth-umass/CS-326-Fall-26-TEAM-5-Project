import fs from "node:fs/promises";

const DIR = new URL("../data/", import.meta.url);
const FILE = new URL("politicians.json", DIR);

const SEED = [
  { name: "Warren, Elizabeth", party: "Democratic", state: "Massachusetts", chamber: "Senate" },
  { name: "Markey, Edward J.", party: "Democratic", state: "Massachusetts", chamber: "Senate" },
  { name: "Neal, Richard E.", party: "Democratic", state: "Massachusetts", district: 1, chamber: "House of Representatives" },
];

let politicians;

async function load() {
  if (politicians) return politicians;
  try {
    politicians = JSON.parse(await fs.readFile(FILE, "utf8"));
  } catch (err) {
    if (err.code !== "ENOENT") throw err;
    politicians = SEED;
    await save();
  }
  return politicians;
}

async function save() {
  await fs.mkdir(DIR, { recursive: true });
  await fs.writeFile(FILE, JSON.stringify(politicians, null, 2));
}

export const all = load;

export async function add(politician) {
  const list = await load();
  if (list.some((p) => p.name === politician.name)) return null;
  list.push(politician);
  await save();
  return politician;
}

export async function remove(name) {
  const list = await load();
  const i = list.findIndex((p) => p.name === name);
  if (i === -1) return false;
  list.splice(i, 1);
  await save();
  return true;
}
