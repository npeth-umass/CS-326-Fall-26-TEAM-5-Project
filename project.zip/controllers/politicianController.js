import * as repo from "../repositories/politicianRepository.js";

const REQUIRED = ["name", "party", "state", "chamber"];
const FIELDS = [...REQUIRED, "district"];

// GET /politicians?name=&state=&party=&chamber=&limit=&offset=
export async function list(req, res) {
  const { limit = 250, offset = 0 } = req.query;
  let members = await repo.all();

  for (const field of ["name", "party", "state", "chamber"]) {
    const q = req.query[field];
    if (q) members = members.filter((p) => p[field]?.toLowerCase().includes(String(q).toLowerCase()));
  }

  res.json({
    members: members.slice(Number(offset), Number(offset) + Number(limit)),
    pagination: { count: members.length },
  });
}

// POST /politicians
export async function add(req, res) {
  const body = req.body ?? {};
  const missing = REQUIRED.filter((f) => !body[f]);
  if (missing.length) return res.status(400).json({ error: `Missing: ${missing.join(", ")}` });

  const politician = Object.fromEntries(FIELDS.filter((f) => body[f] !== undefined && body[f] !== "").map((f) => [f, body[f]]));
  if (politician.district !== undefined) politician.district = Number(politician.district);

  const created = await repo.add(politician);
  if (!created) return res.status(409).json({ error: `${politician.name} already exists` });
  res.status(201).json(created);
}

// DELETE /politicians/:name
export async function remove(req, res) {
  const removed = await repo.remove(req.params.name);
  res.status(removed ? 204 : 404).end();
}
